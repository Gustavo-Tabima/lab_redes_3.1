import socket
from random import randrange
import datetime
import time
from tqdm import tqdm

IP = socket.gethostbyname(socket.gethostname())
PORT = 4457
ADDR = (IP, PORT)
SIZE = 1024
FORMAT = "utf-8"

"TCP socket and connecting to the server"
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)
print(f" [+] Client connected to server")

tiempo_inc = time.time()
numeroFile = randrange(100)
try:
    # Send data
    str_message = "SYN"
    str_message = str_message.encode(FORMAT)
    message = str_message
    client.send(message)

    # Look for the response
    amount_received = 0
    amount_expected =2
    while amount_received < amount_expected:
        data = client.recv(4096)
        print("Recibido: " + data.decode(FORMAT))
        if(data.decode(FORMAT) == "SYN ACK"):
            str_message = "ACK"
            str_message = str_message.encode(FORMAT)
            message = str_message
            client.send(message)

        if (data.decode(FORMAT) == "FILE?"):
            str_message = "FILE"
            str_message = str_message.encode(FORMAT)
            message = str_message
            client.send(message)

            "Receiving the filename and filesize from the server."
            data = client.recv(SIZE).decode(FORMAT)
            item = data.split("_")
            FILENAME = item[0]
            FILESIZE = int(item[1])

            print("[+] Filename and filesize received from the client")
            client.send("Filename and filesize received".encode(FORMAT))

            "Data trasnfer"
            bar = tqdm(range(FILESIZE), f"Receiving {FILENAME}", unit="B", unit_scale=True, unit_divisor=SIZE)

            with open(f"{FILENAME}", "w") as f:
                while True:
                    data = client.recv(SIZE).decode(FORMAT)

                    if not data:
                        break

                    f.write(data)
                    client.send("Data received.".encode(FORMAT))

                    bar.update(len(data))

            str_message = "FILE ACK"
            str_message = str_message.encode(FORMAT)
            message = str_message
            client.send(message)

        if(data.decode(FORMAT) == "FINAL"):
            print('closing socket')
            client.close()
            e = datetime.datetime.now()
            f= open("logs/log"+str(e.month)+"-"+str(e.day)+"-"+str(e.hour)+"-"+str(e.minute)+"-"+str(e.second)+ ".txt","w+")
            f.write("\n" +"Este es el cliente de conexión numero: " + str(numeroFile))
            f.write("\n" +"La entrega del archivo fue exitosa")
            tiempo_fin = time.time()
            f.write("\n" +"El tiempo de entrega fue de " + str((tiempo_fin - tiempo_inc)))
            amount_expected = 100000


        else:
          datos = data.decode(FORMAT)
          file = open("Rdata/datos_recieved "+str(numeroFile),"w+")
          file.write(datos)
          file.close()
          amount_received += 1

finally:
    print("FIN DEL LAB PAL CLIENTE")

