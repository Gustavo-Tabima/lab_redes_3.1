import os
import socket
import sys
import hashlib
import datetime
import time
from tqdm import tqdm

#1. Debe implementar el protocolo de control de transmisión (TCP por sus siglas en inglés) para
#transmitir un archivo hacía un cliente
#2. Debe correr sobre una máquina con sistema operativo UbuntuServer 20.04
#3. La aplicación debe soportar al menos 25 conexiones concurrentes. (check)
#4. Debe tener dos archivos disponibles para su envío a los clientes: un archivo de tamaño 100 MB y
#otro de 250 MB. (check)
#5. La aplicación debe permitir seleccionar qué archivo desea transmitir a los clientes conectados y a
#cuántos clientes en simultáneo; a todos se les envía el mismo archivo durante una transmisión. (check)
#6. Debe enviar a cada cliente un valor hash calculado para el archivo transmitido; este valor será usado
#para validar la integridad del archivo enviado en el aplicativo de cliente.(check)
#7. La transferencia de archivos a los clientes definidos en la prueba debe realizarse solo cuando el
#número de clientes indicados estén conectados y el estado de todos sea listo para recibir. (tengo problemas para hacer esto)


# Create a TCP/IP socket
IP = socket.gethostbyname(socket.gethostname())
PORT = 4457
ADDR = (IP, PORT)
SIZE = 1024
FORMAT = "utf-8"
FILENAME = ""
FILESIZE = 0

inp = input(' 1 Para la file de 100 MB, 2 para la de 250 MB ')
if str(inp) == "1":
    archivo = open("100.txt", "rb")
    FILENAME = "100.txt"
    FILESIZE = os.path.getsize(FILENAME)
elif str(inp) == "2":
    archivo = open("250.txt", "rb")
    FILENAME = "250.txt"
    FILESIZE = os.path.getsize(FILENAME)

else:
    print("ENTRADA INVÁLIDA")
    sys.exit('\033[93m' + 'Afectas las reglas del lab.')

inp2 = int(input('a cuantos les quiere enviar esto?'))
if int(inp2) > 25:
    print("valor de reenvío inválido")
    sys.exit('\033[93m' + 'Afectas las reglas del lab.')
else:
    valor_de_reenvios = inp2


"Creating a TCP server socket"
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
server.listen(inp2)
print("[+] Listening...")

"Accepting the connection from the client"
valor_de_conexiones = 0
while valor_de_conexiones <= valor_de_reenvios:
    tiempo_inc = time.time()
    # Wait for a connection
    print('waiting for a connection')
    conn, addr = server.accept()
    valor_de_conexiones = valor_de_conexiones+1
    try:
        print(f" [+] Client connected from {addr[0]}:{addr[1]}")

        "Sending the filename and filesize to the client"
        while True:
            data = conn.recv(4096)
            string_data = data
            print('Su mensaje ha sido recibido')
            if string_data.decode(FORMAT) == "SYN":
                print('sending data back to the client')
                str_respuesta = "SYN ACK"
                str_respuesta = str_respuesta.encode(FORMAT)
                conn.send(str_respuesta)

            elif string_data.decode(FORMAT) == "ACK":
               str_respuesta = "FILE?"
               str_respuesta = str_respuesta.encode(FORMAT)
               conn.send(str_respuesta)
               
            elif string_data.decode(FORMAT) == "FILE":

              "Sending the filename and filesize to the server"
              data = f"{FILENAME}_{FILESIZE}"
              conn.send(data.encode(FORMAT))
              msg = conn.recv(SIZE).decode(FORMAT)
              print(f"SERVER: {msg}")

              "Data transfer"
              bar = tqdm(range(FILESIZE),f"Sending {FILENAME}", unit="B", unit_scale=True, unit_divisor=SIZE)

              with open(FILENAME, "r") as f:
                  while True:
                      data = f.read(SIZE)

                      if not data:
                          break

                      conn.send(data.encode(FORMAT))
                      msg = conn.recv(SIZE).decode(FORMAT)

                      bar.update(len(data))

            elif string_data.decode(FORMAT) == "FILE ACK":
              str_respuesta = "FINAL"
              str_respuesta = str_respuesta.encode(FORMAT)
              conn.send(str_respuesta)
              text_valor = str(valor_de_conexiones)
              e = datetime.datetime.now()
              f= open("logs/log"+str(e.month)+"-"+str(e.day)+"-"+str(e.hour)+"-"+str(e.minute)+"-"+str(e.second)+ ".txt","w+")
              f.write(str(archivo.__dir__))
              f.write( "\n" +"Este es el cliente de conexión numero: " + text_valor)
              f.write("\n" +"La entrega del archivo fue exitosa")
              tiempo_fin = time.time()
              f.write("\n" +"El tiempo de entrega fue de " + str((tiempo_fin - tiempo_inc)))

            else:
                print('no data from', addr)
                break
    finally:
        conn.close()
        server.close()